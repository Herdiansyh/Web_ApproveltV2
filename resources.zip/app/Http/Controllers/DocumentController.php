<?php

namespace App\Http\Controllers;

use App\Models\Document;
use App\Models\DocumentField;
use App\Models\Workflow;
use App\Models\DocumentNameSeries;
use App\Http\Requests\DocumentNameSeriesRequest;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\RedirectResponse;

class DocumentController extends Controller
{
    use AuthorizesRequests;

    public function index()
    {
        return Inertia::render('Admin/Documents/Index', [
            'documents' => Document::with(['fields', 'nameSeries'])->paginate(20),
        ]);
    }

    public function store(Request $request)
    {
        $this->authorize('create', Document::class);
        
        // Validate prefix uniqueness before creating document
        if ($request->filled('prefix')) {
            $existingPrefix = DocumentNameSeries::where('prefix', $request->prefix)->exists();
            if ($existingPrefix) {
                throw ValidationException::withMessages([
                    'prefix' => 'Prefix sudah digunakan oleh dokumen lain. Silakan pilih prefix yang berbeda.'
                ]);
            }
        }
        
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'is_active' => 'sometimes|boolean',
            'default_columns' => 'nullable|array',
            'default_columns.*.name' => 'required|string|max:255',
            'default_columns.*.key' => 'required|string|max:255',
            'default_columns.*.type' => 'required|string|in:text,number,date,select',
            'default_columns.*.required' => 'required|boolean',
            'default_columns.*.options' => 'nullable|array',
            'default_columns.*.options.*' => 'nullable|string',

            // optional name series config, can be filled from create/edit modal
            'series_pattern' => 'nullable|string|max:255',
            'prefix' => 'nullable|string|max:50',
            'reset_type' => 'nullable|in:none,monthly,yearly',
            'current_number' => 'nullable|integer|min:0',
        ]);

        $document = Document::create([
            'name' => $data['name'],
            'description' => $data['description'] ?? null,
            'is_active' => array_key_exists('is_active', $data) ? (bool)$data['is_active'] : true,
            'default_columns' => $data['default_columns'] ?? null,
        ]);

        // if name series is provided at creation time, configure it here
        if (!empty($data['series_pattern'])) {
            $series = DocumentNameSeries::firstOrCreate(
                ['document_id' => $document->id],
                [
                    'series_pattern' => 'yyyy-mm-####',
                    'prefix' => null,
                    'current_number' => 0,
                    'reset_type' => 'none',
                    'last_reset_at' => null,
                ]
            );

            $series->series_pattern = $data['series_pattern'];
            $series->prefix = $data['prefix'] ?? null;
            $series->reset_type = $data['reset_type'] ?? 'none';
            if (array_key_exists('current_number', $data) && $data['current_number'] !== null) {
                $series->current_number = (int) $data['current_number'];
            }
            $series->save();
        }

        return back()->with('success', 'Dokumen berhasil ditambahkan.');
    }

    public function update(Request $request, Document $document)
    {
        $this->authorize('update', $document);
        
        // Validate prefix uniqueness before updating document
        if ($request->filled('prefix')) {
            $existingPrefix = DocumentNameSeries::where('prefix', $request->prefix)
                ->where('document_id', '!=', $document->id)
                ->exists();
            if ($existingPrefix) {
                throw ValidationException::withMessages([
                    'prefix' => 'Prefix sudah digunakan oleh dokumen lain. Silakan pilih prefix yang berbeda.'
                ]);
            }
        }
        
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'is_active' => 'sometimes|boolean',
            'default_columns' => 'nullable|array',
            'default_columns.*.name' => 'required|string|max:255',
            'default_columns.*.key' => 'required|string|max:255',
            'default_columns.*.type' => 'required|string|in:text,number,date,select',
            'default_columns.*.required' => 'required|boolean',
            'default_columns.*.options' => 'nullable|array',
            'default_columns.*.options.*' => 'nullable|string',

            // optional name series config from modal
            'series_pattern' => 'nullable|string|max:255',
            'prefix' => 'nullable|string|max:50',
            'reset_type' => 'nullable|in:none,monthly,yearly',
            'current_number' => 'nullable|integer|min:0',
        ]);

        $document->update([
            'name' => $data['name'],
            'description' => $data['description'] ?? null,
            'is_active' => array_key_exists('is_active', $data) ? (bool)$data['is_active'] : $document->is_active,
            'default_columns' => $data['default_columns'] ?? $document->default_columns,
        ]);

        // update name series if provided
        if (!empty($data['series_pattern'])) {
            $series = DocumentNameSeries::firstOrCreate(
                ['document_id' => $document->id],
                [
                    'series_pattern' => 'yyyy-mm-####',
                    'prefix' => null,
                    'current_number' => 0,
                    'reset_type' => 'none',
                    'last_reset_at' => null,
                ]
            );

            $series->series_pattern = $data['series_pattern'];
            $series->prefix = $data['prefix'] ?? null;
            $series->reset_type = $data['reset_type'] ?? 'none';
            if (array_key_exists('current_number', $data) && $data['current_number'] !== null) {
                $series->current_number = (int) $data['current_number'];
            }
            $series->save();
        }

        return back()->with('success', 'Dokumen berhasil diperbarui.');
    }

    public function destroy(Document $document)
{
    $this->authorize('delete', $document);

    $usedBySubmissions = $document->submissions()->exists();
    $usedByWorkflows = Workflow::where('document_id', $document->id)->exists();

      if ($usedBySubmissions || $usedByWorkflows) {
        throw ValidationException::withMessages([
            'error' => 'Dokumen tidak dapat dihapus karena sudah digunakan. Non-aktifkan dokumen jika tidak ingin digunakan lagi.'
        ]);
    }

    $document->delete();

      return redirect()->back()->with('success', 'Dokumen berhasil dihapus.');

}


    // ------------------------------
    // Document Type Fields Endpoints
    // ------------------------------

    public function addField(Request $request, Document $document): RedirectResponse
    {
        $this->authorize('update', $document);
        $data = $request->validate([
            'name' => 'required|string|max:100',
            'label' => 'required|string|max:255',
            'type' => 'required|string|in:text,textarea,number,date,select,label',
            'required' => 'boolean',
            'order' => 'nullable|integer|min:0',
            'options' => 'nullable|array', // for select
            'options.*' => 'nullable|string',
        ]);

        $field = new DocumentField([
            'name' => $data['name'],
            'label' => $data['label'],
            'type' => $data['type'],
            'required' => $data['type'] === 'label' ? false : (bool)($data['required'] ?? false),
            'order' => $data['order'] ?? 0,
            'options_json' => isset($data['options']) ? json_encode(array_values($data['options'])) : null,
        ]);
        $document->fields()->save($field);

        return back()->with('success', 'Field ditambahkan.');
    }

    public function updateField(Request $request, Document $document, DocumentField $field)
    {
        $this->authorize('update', $document);
        abort_unless($field->document_id === $document->id, 404);

        $data = $request->validate([
            'label' => 'sometimes|string|max:255',
            'type' => 'sometimes|string|in:text,textarea,number,date,select,label',
            'required' => 'sometimes|boolean',
            'order' => 'sometimes|integer|min:0',
            'options' => 'nullable|array',
            'options.*' => 'nullable|string',
        ]);

        $field->fill([
            'label' => $data['label'] ?? $field->label,
            'type' => $data['type'] ?? $field->type,
            'required' => ($data['type'] ?? $field->type) === 'label' ? false : (array_key_exists('required', $data) ? (bool)$data['required'] : $field->required),
            'order' => $data['order'] ?? $field->order,
            'options_json' => array_key_exists('options', $data) ? json_encode(array_values($data['options'] ?? [])) : $field->options_json,
        ])->save();

        return back()->with('success', 'Field diperbarui.');
    }

    public function deleteField(Document $document, DocumentField $field)
    {
        $this->authorize('update', $document);
        abort_unless($field->document_id === $document->id, 404);
        $field->delete();
        return back()->with('success', 'Field dihapus.');
    }

    // ------------------------------
    // Document Name Series Endpoints
    // ------------------------------

    public function updateNameSeries(DocumentNameSeriesRequest $request, Document $document)
    {
        $this->authorize('update', $document);

        $data = $request->validated();

        $series = DocumentNameSeries::firstOrCreate(
            ['document_id' => $document->id],
            [
                'series_pattern' => 'yyyy-mm-####',
                'prefix' => null,
                'current_number' => 0,
                'reset_type' => 'none',
                'last_reset_at' => null,
            ]
        );

        $series->series_pattern = $data['series_pattern'];
        $series->prefix = $data['prefix'] ?? null;
        $series->reset_type = $data['reset_type'];
        if (array_key_exists('current_number', $data) && $data['current_number'] !== null) {
            $series->current_number = (int) $data['current_number'];
        }
        $series->save();

        return back()->with('success', 'Name Series berhasil diperbarui.');
    }

    public function resetNameSeries(Document $document)
    {
        $this->authorize('update', $document);

        $series = $document->nameSeries;
        if (!$series) {
            return back()->with('error', 'Name Series belum dikonfigurasi untuk dokumen ini.');
        }

        $series->current_number = 0;
        $series->last_reset_at = now();
        $series->save();

        return back()->with('success', 'Counter Name Series berhasil di-reset.');
    }
}

