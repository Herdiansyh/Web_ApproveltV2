import { useForm, Head, Link } from "@inertiajs/react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import GuestLayout from "@/Layouts/GuestLayout";
import { setupCsrfTokenAfterLogin } from "@/utils/csrfToken";

export default function Login({ status, canResetPassword }) {
    const { data, setData, post, processing, errors, reset } = useForm({
        email: "",
        password: "",
        remember: false,
    });

    const submit = (e) => {
        e.preventDefault();
        post(route("login"), {
            onFinish: () => reset("password"),
            onSuccess: async () => {
                // Refresh CSRF token after successful login
                try {
                    await setupCsrfTokenAfterLogin();
                } catch (error) {
                    // Handle CSRF token refresh error silently
                }
            },
        });
    };

    return (
        <GuestLayout>
            <Head title="Log in" />

            <Card
                className="w-full max-w-md shadow-lg"
                style={{ borderRadius: "15px" }}
            >
                <CardHeader>
                    <CardTitle className="text-2xl flex flex-col items-center  font-semibold text-center">
                        <img src="/icon.png" alt="" className="w-12 " />
                    </CardTitle>
                    <CardTitle className="text-2xl font-semibold text-center">
                        Login{" "}
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {status && (
                        <Alert className="mb-4">
                            <AlertDescription>{status}</AlertDescription>
                        </Alert>
                    )}

                    <form onSubmit={submit} className="space-y-4">
                        <div className="space-y-1">
                            <Label htmlFor="email">Email</Label>
                            <Input
                                id="email"
                                type="email"
                                name="email"
                                value={data.email}
                                autoComplete="username"
                                onChange={(e) =>
                                    setData("email", e.target.value)
                                }
                            />
                            {errors.email && (
                                <p className="text-sm text-destructive">
                                    {errors.email}
                                </p>
                            )}
                        </div>

                        <div className="space-y-1">
                            <Label htmlFor="password">Password</Label>
                            <Input
                                id="password"
                                type="password"
                                name="password"
                                value={data.password}
                                autoComplete="current-password"
                                onChange={(e) =>
                                    setData("password", e.target.value)
                                }
                            />
                            {errors.password && (
                                <p className="text-sm text-destructive">
                                    {errors.password}
                                </p>
                            )}
                        </div>

                        <div className="flex items-center justify-between">
                          

                            {canResetPassword && (
                                <Link
                                    href={route("password.request")}
                                    className="text-sm text-muted-foreground hover:text-primary underline"
                                >
                                    Forgot password?
                                </Link>
                            )}
                        </div>

                        <Button
                            type="submit"
                            className="w-full"
                            style={{ borderRadius: "15px" }}
                            disabled={processing}
                        >
                            Log in
                        </Button>

                        
                    </form>
                </CardContent>
            </Card>
        </GuestLayout>
    );
}
