<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Pastikan tabel subdivisions sudah dibuat dulu sebelum ini
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');

            // relasi ke subdivision
            $table->foreignId('subdivision_id')
                  ->nullable()
                  ->constrained('subdivisions')
                  ->nullOnDelete();

            // role user
            $table->enum('role', ['employee', 'direktur', 'admin'])
                  ->default('employee');

            // relasi ke division
            $table->foreignId('division_id')
                  ->nullable()
                  ->constrained()
                  ->nullOnDelete();

            $table->rememberToken();
            $table->timestamps();
        });

        // tabel password reset
        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        // tabel sessions
        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sessions');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('users');
    }
};
